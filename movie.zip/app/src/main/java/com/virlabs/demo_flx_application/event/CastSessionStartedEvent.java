package com.virlabs.demo_flx_application.event;

/**
 * Created by Tamim on 28/09/2019.

 */

public class CastSessionStartedEvent {

    public CastSessionStartedEvent() {

    }
}
