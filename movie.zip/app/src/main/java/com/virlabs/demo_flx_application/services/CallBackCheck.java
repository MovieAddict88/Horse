package com.virlabs.demo_flx_application.services;

public interface CallBackCheck {
    void onPurchase();
    void onNotPurchase();
}