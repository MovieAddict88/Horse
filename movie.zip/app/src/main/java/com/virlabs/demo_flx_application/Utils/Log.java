package com.virlabs.demo_flx_application.Utils;

/**
 * Created by Tamim on 21/3/17.
 */
public class Log {
    public static void log(String msg) {
        android.util.Log.d("Nzm",""+msg);
    }
}
